package hotelBooking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.HotelBookingPageBeam;
import pages.LoginPageBeam;


public class StepDef {
	
	private WebDriver driver;
	private LoginPageBeam loginPageBeam;
	private HotelBookingPageBeam hotelpage;
	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\sinmural\\Documents\\My Received Files\\chromedriver.exe");
		driver=new ChromeDriver();
		loginPageBeam= new LoginPageBeam(driver);
		hotelpage = new HotelBookingPageBeam(driver);
		
	}
	
	@Given("^Login form is open$")
	public void login_form_is_open() throws Throwable {
		 driver.get("file:///D:/sindhu4/hotelBooking/src/main/webapp/WEB-INF/views/login.html");
	}

	@When("^User name and Password are valid$")
	public void user_name_and_Password_are_valid() throws Throwable {
		loginPageBeam.setuName("capgemini");
		loginPageBeam.setPwd("capg1234");
		loginPageBeam.setBtn();
	}

	@Then("^Navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
		String url = driver.getCurrentUrl();
	    assertEquals(url, "file:///D:/sindhu4/hotelBooking/src/main/webapp/WEB-INF/views/hotelbooking.html");
	}
	
	@When("^Click on next$")
	public void click_on_next() throws Throwable {
		hotelpage.setBtn2();
	}

	@Then("^Display alert message saying to fill the First Name$")
	public void dispaly_aler_message_saying(String arg1) throws Throwable {
	   String alert = driver.switchTo().alert().getText();
	   assertEquals(alert, "Please fill the First Name");
	   driver.switchTo().alert().accept();
	}
	
	@When("^Valid first name is given and press next$")
	public void valid_first_name_is_given_and_press_next() throws Throwable {
	    hotelpage.setFirstName("Sindhu");
	    hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the Last Name$")
	public void display_alert_message_saying(String arg1) throws Throwable {
		String alert = driver.switchTo().alert().getText();
		   assertEquals(alert, "Please fill the Last Name");
		   driver.switchTo().alert().accept();
	}
	
	@When("^Valid last name is given and press next$")
	public void valid_last_name_is_given_and_press_next() throws Throwable {
	    hotelpage.setLastName("Murali");
	    hotelpage.setBtn2();
	}
	
	@Then("^Display alert message saying  to fill the Email$")
	public void display_alert_message_saying_to_fill_the_Email() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please fill the Email");
		driver.switchTo().alert().accept();
	}
	
	@When("^Invalid email is given$")
	public void invalid_email_is_given() throws Throwable {
	    hotelpage.setEmail("789654");
	    hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the valid email$")
	public void display_alert_message_saying_to_fill_the_valid_email() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please enter valid Email Id.");
		driver.switchTo().alert().accept();
		
	}

	@When("^Valid email is given and press next$")
	public void valid_email_is_given_and_press_next() throws Throwable {
		hotelpage.setEmail("sindhu@gmail.com");
	    hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the Mobile No\\.$")
	public void display_alert_message_saying_to_fill_the_Mobile_No() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please fill the Last Name");
		driver.switchTo().alert().accept();
	}
	
	@When("^Invalid mobile is given$")
	public void invalid_mobile_is_given() throws Throwable {
	    hotelpage.setPhone("7896");
	    hotelpage.setBtn2();
	}

	@Then("^Display alert message saying to fill the valid mobile no$")
	public void display_alert_message_saying_to_fill_the_valid_mobile_no() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please enter valid Contact no.");
		driver.switchTo().alert().accept();
	}

	@When("^Valid mobile is given and press next$")
	public void valid_mobile_is_given_and_press_next() throws Throwable {
		hotelpage.setPhone("7894562367");
	    hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to select city$")
	public void display_alert_message_saying_to_select_city() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please select city");
		driver.switchTo().alert().accept();
	}
	
	
	@When("^Valid City is given$")
	public void valid_City_is_given() throws Throwable {
		hotelpage.setcity("Pune");
		hotelpage.setBtn2();
	   
	}

	@Then("^Display alert message saying  to select state$")
	public void display_alert_message_saying_to_select_state() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please select state");
		driver.switchTo().alert().accept();
	}

	@When("^Valid guests are given$")
	public void valid_guests_are_given() throws Throwable {
		hotelpage.setGuest("3");;
		hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the cardholder name$")
	public void display_alert_message_saying_to_fill_the_cardholder_name() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please fill the Card holder name");
		driver.switchTo().alert().accept();
	}

	@When("^Valid cardholder name is given$")
	public void valid_cardholder_name_is_given() throws Throwable {
		hotelpage.setCardHolderName("Sindhu");
		hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the debit card number$")
	public void display_alert_message_saying_to_fill_the_debit_card_number() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please fill the Debit card Number");
		driver.switchTo().alert().accept();
	}

	@When("^Valid card number is given$")
	public void valid_card_number_is_given() throws Throwable {
		hotelpage.setDbCardNumber("12345678963");
		hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the cvv$")
	public void display_alert_message_saying_to_fill_the_cvv() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please fill the Debit card Number");
		driver.switchTo().alert().accept();
	}

	@When("^Valid cvv is given$")
	public void valid_cvv_is_given() throws Throwable {
		hotelpage.setCvv("123");;
		hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the expiry month$")
	public void display_alert_message_saying_to_fill_the_expiry_month() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please fill expiration month");
		driver.switchTo().alert().accept();
	}

	@When("^Valid expiry month is given$")
	public void valid_expiry_month_is_given() throws Throwable {
		hotelpage.setExpiryDate("13-05-2020");
		hotelpage.setBtn2();
	}

	@Then("^Display alert message saying  to fill the expiry year$")
	public void display_alert_message_saying_to_fill_the_expiry_year() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		assertEquals(alert, "Please fill the expiration year");
		driver.switchTo().alert().accept();
	}
	
	@After
	public void close{
		driver.close();
	}

}
