package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingPageBeam {
	
	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;

	@FindBy(name="Email")
	private WebElement email;
	
	@FindBy(name="Phone")
	private WebElement phone;
	
	@FindBy(name="address")
	private WebElement address;
	
	@FindBy(how=How.XPATH,using="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	private WebElement city;
	
	@FindBy(how=How.XPATH,using="/html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
	private WebElement state;
	
	@FindBy(how=How.XPATH,using="/html/body/div/div/form/table/tbody/tr[10]/td[2]/select")
	private WebElement noOfGuests;
	
	@FindBy(id="txtCardholderName")
	private WebElement cardHolderName;
	
	@FindBy(name="debit")
	private WebElement dbCardNumber;
	
	@FindBy(name="cvv")
	private WebElement cvv;
	
	@FindBy(name="month")
	private WebElement expiryDate;
	
	@FindBy(name="year")
	private WebElement expiryYear;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"btnPayment\"]")
	private WebElement btn;
	
	
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName); 
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}
	
	public void setAddress(String address) {
		this.address.sendKeys(address);
	}
	
	public void setcity(String cit) {
		this.city.sendKeys(cit);
	}
	
	public void setstate(String stat) {
		this.state.sendKeys(stat);
	}
	
	public void setGuest(String guest) {
		this.noOfGuests.sendKeys(guest);
	}
	
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public void setDbCardNumber(String dbCardNumber) {
		this.dbCardNumber.sendKeys(dbCardNumber);
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate.sendKeys(expiryDate);
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear.sendKeys(expiryYear);
	}

	public void setBtn2() {
		this.btn.click();
	}

	
	public HotelBookingPageBeam(WebDriver driver2) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
}
