package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBeam {
	
	WebDriver driver;
	
	@FindBy(name = "userName")
	private WebElement uName;
	
	@FindBy(name = "userPwd") 
	private WebElement pwd;
	
	@FindBy(how = How.XPATH, using="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	private WebElement btn;

	public LoginPageBeam(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setuName(String userName) {
		uName.sendKeys(userName);
	}

	public void setPwd(String userPwd) {
		pwd.sendKeys(userPwd);
	}

	public void setBtn() {
		btn.click();
	}
	
}
