package login;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	
	private WebDriver driver;
	private WebElement element;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "D:/Users/sinmural/Documents/My Received Files/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:8085/BankApp/");
	}
	
	
	@Given("^Open login page$")
	public void open_login_page() throws Throwable {
		driver.get("http://localhost:8085/BankApp/");
	}

	@When("^username and password valid$")
	public void username_and_password_valid() throws Throwable {
		element = driver.findElement(By.name("customerId"));
		element.sendKeys("2");
		element = driver.findElement(By.name("customerPwd"));
		element.sendKeys("123456");
		element.submit();
	}

	@Then("^navigate to main page$")
	public void navigate_to_main_page() throws Throwable {
	    String url = driver.getCurrentUrl();
	    assertTrue(url.equals("http://localhost:8085/BankApp/validateLogin"));
	}
	
	@When("^username and password invalid$")
	public void username_and_password_invalid() throws Throwable {
		element = driver.findElement(By.name("customerId"));
		element.sendKeys("3");
		element = driver.findElement(By.name("customerPwd"));
		element.sendKeys("123456");
		element.submit();
	
	}

	@Then("^stay in login page$")
	public void stay_in_login_page() throws Throwable {
		String url = driver.getCurrentUrl();
	    assertTrue(url.equals("http://localhost:8085/BankApp/"));
	}

}
