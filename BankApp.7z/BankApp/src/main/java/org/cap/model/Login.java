package org.cap.model;

public class Login {
	private int customerId;
	private String customerpwd;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerpwd() {
		return customerpwd;
	}
	public void setCustomerpwd(String customerpwd) {
		this.customerpwd = customerpwd;
	}
	public Login(int customerId, String customerpwd) {
		super();
		this.customerId = customerId;
		this.customerpwd = customerpwd;
	}
	public Login() {
	}
	}


