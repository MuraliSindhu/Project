package registration;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private WebElement element;
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@Given("^Student Details form$")
	public void student_Details_form() throws Throwable {
		driver.get("http://localhost:8081/StudentRegForm/");
	}

	@When("^All the feilds are entered correct$")
	public void all_the_feilds_are_entered_correct() throws Throwable {
		element=driver.findElement(By.name("firstName"));
		element.sendKeys("Shravya");
		element=driver.findElement(By.name("lastName"));
		element.sendKeys("Gunnala");
		element=driver.findElement(By.name("address"));
		element.sendKeys("Patancheru");
		element=driver.findElement(By.name("city"));
		element.sendKeys("Hyderabad");
		element=driver.findElement(By.name("state"));
		element.sendKeys("Telengana");
		element=driver.findElement(By.name("gender"));
		element.sendKeys("female");
		element=driver.findElement(By.name("course"));
		element.sendKeys("BE");
		element=driver.findElement(By.name("mobilenum"));
		element.sendKeys("1234567890");
		element.submit();
	}

	@Then("^Navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
		System.out.println(driver.switchTo().alert().getText());
        driver.switchTo().alert().accept();
		String url=driver.getCurrentUrl();
		 assertTrue(url.equals("http://localhost:8081/StudentRegForm/next"));
	}
	
	@Given("^open payment page$")
	public void open_payment_page() throws Throwable {
		driver.get("http://localhost:8081/StudentRegForm/next");
	}

	@When("^All the feilds entered are correct$")
	public void all_the_feilds_entered_are_correct() throws Throwable {
		element=driver.findElement(By.name("name"));
		element.sendKeys("SHRAVYA");
		element=driver.findElement(By.name("cardNo"));
		element.sendKeys("1234432123456789");
		element=driver.findElement(By.name("cvvNo"));
		element.sendKeys("567");
		element=driver.findElement(By.name("exDate"));
		element.sendKeys("09/20");
		element.submit();
	}

	@Then("^show popup$")
	public void show_popup() throws Throwable {
		System.out.println(driver.switchTo().alert().getText());
        driver.switchTo().alert().accept();
        String url=driver.getCurrentUrl();
		 assertTrue(url.equals("http://localhost:8081/StudentRegForm/"));
	}

	@After
	public void teardown()
	{
		driver.close();
	}

}



