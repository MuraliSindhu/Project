package registration;



import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import page.RegistrationBean;



public class registrationTest {
	private WebDriver driver;
	private RegistrationBean registerPageBean;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\chromedriver.exe");
	
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		registerPageBean=new RegistrationBean(driver);
	}
	
	@Test
	public void  check_loginpage_naviagation() {
		driver.get("http://localhost:8081/StudentRegForm/");
		/*String pageHeading=registerPageBean.getPageTitle();
		
		assertTrue(pageHeading.equals("Banking Application"));*/

		
		registerPageBean.navigate_NextPage("Shravya", "Gunnala","Patancheru","Hyderbad","Telangana","female","BE","1234567890");
		System.out.println(driver.switchTo().alert().getText());
        driver.switchTo().alert().accept();
	}
	
	
	@After
	public void tearDown() {
		//driver.close();
	}
}
