package page;

public class PaymentBean {

}
