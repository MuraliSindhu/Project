package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegistrationBean {
	WebDriver driver;
	/*private By firstName =By.name("firstName");
	private By lastName=By.name("lastName");
	private By address=By.name("address");
	private By city=By.name("city");
	private By state=By.name("state");
	private By gender=By.name("gender");
	private By course=By.name("course");
	private By mobile=By.name("mobile");
	private By subdetails=By.name("next");*/
	
	@FindBy(name="firstName",how=How.NAME)
	private WebElement stuFName;
	@FindBy(name="lastName")
	private WebElement stuLName;
	@FindBy(name="address",how=How.NAME)
	private WebElement stuAddress;
	@FindBy(name="city",how=How.NAME)
	private WebElement stuCity;
	@FindBy(name="state",how=How.NAME)
	private WebElement stuState;
	//@FindBy(name="gender",how=How.NAME)
	private WebElement stuGender;
	@FindBy(name="course",how=How.NAME)
	private WebElement stuCourse;
	@FindBy(name="mobilenum",how=How.NAME)
	private WebElement stuMobile;
	
	@FindBy(id="save")
	private WebElement subdetails;
	
	/*//private By pageheading=By.xpath("//*[@id=\"mainCnt\"]/h1");
	@FindBy(xpath="//*[@id=\"mainCnt\"]/h1")
	private WebElement pageheading;
	*/
	
	public RegistrationBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setFirstName(String fName) {
		//driver.findElement(userName).sendKeys(usrName);
		stuFName.sendKeys(fName);
	}
	public void setLastName(String lName) {
		//driver.findElement(userName).sendKeys(usrName);
		stuLName.sendKeys(lName);
	}
	public void setAddress(String add) {
		//driver.findElement(userName).sendKeys(usrName);
		stuAddress.sendKeys(add);
	}
	public void setCity(String city) {
		//driver.findElement(userName).sendKeys(usrName);
		stuCity.sendKeys(city);
	}
	public void setState(String state) {
		//driver.findElement(userName).sendKeys(usrName);
		stuState.sendKeys(state);
	}
	public void setGender(String gender) {
		//driver.findElement(userName).sendKeys(usrName);
		stuGender=driver.findElement(By.id(gender));
		stuGender.click();
	}
	public void setCourse(String course) {
		//driver.findElement(userName).sendKeys(usrName);
		stuCourse.sendKeys(course);
	}
	public void setMobile(String mobile) {
		//driver.findElement(userName).sendKeys(usrName);
		stuMobile.sendKeys(mobile);
	}
	
	public void setSaveDetails() {
		//driver.findElement(subLogin).submit();
		subdetails.submit();
	}
	
	
	/*public String getPageTitle() {
		//return driver.findElement(pageheading).getText();
		return pageheading.getText();
	}*/

	
	
	public void navigate_NextPage(String fName,String lName,String add,String city,
			String state,String gender,String course,String mobile) {
		this.setFirstName(fName);
		this.setLastName(lName);
		this.setAddress(add);
		this.setCity(city);
		this.setState(state);
		this.setGender(gender);
		this.setCourse(course);
		this.setMobile(mobile);
		this.setSaveDetails();
	}
}
