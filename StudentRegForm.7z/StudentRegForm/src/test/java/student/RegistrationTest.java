package student;

public class RegistrationTest {

}
