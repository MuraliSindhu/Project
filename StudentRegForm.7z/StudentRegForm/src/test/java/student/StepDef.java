package student;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver driver;
	private WebElement element;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:/Users/sinmural/Documents/My Received Files/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
	@Given("^Student details$")
	public void student_details() throws Throwable {
	   driver.get("http://localhost:8085/StudentRegForm/");
	}

	@When("^Student details are valid$")
	public void student_details_are_valid() throws Throwable {
		element=driver.findElement(By.name("firstName"));
		element.sendKeys("Sindhu");
		element=driver.findElement(By.name("lastName"));
		element.sendKeys("Murali");
		element=driver.findElement(By.name("address"));
		element.sendKeys("Erragadda");
		element=driver.findElement(By.name("city"));
		element.sendKeys("Hyderabad");
		element=driver.findElement(By.name("course"));
		element.sendKeys("BE");
		element=driver.findElement(By.name("mobilenum"));
		element.sendKeys("9876547890");
		element.submit();
		driver.switchTo().alert().accept();
	}

	@Then("^Register student details$")
	public void register_student_details() throws Throwable {
		String url = driver.getCurrentUrl();
	    assertTrue(url.equals("http://localhost:8085/StudentRegForm/next")); 
	}
	
	
	@Given("^Payment Details$")
	public void payment_Details() throws Throwable {
	   driver.get("http://localhost:8085/StudentRegForm/next");
	}

	@When("^Payment Details are valid$")
	public void payment_Details_are_valid() throws Throwable {
		element=driver.findElement(By.name("name"));
		element.sendKeys("SINDHU");
		element=driver.findElement(By.name("cardNo"));
		element.sendKeys("1234567890123456");
		element=driver.findElement(By.name("cvvNo"));
		element.sendKeys("114");
		element=driver.findElement(By.name("exDate"));
		element.sendKeys("Hyderabad");
		element.submit();
		driver.switchTo().alert().accept();
	}

	@Then("^successfull payment$")
	public void successfull_payment() throws Throwable {
		driver.close();
	}

}
