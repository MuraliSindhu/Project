package org.capstore.rest.service;

import java.util.List;

import org.capstore.rest.model.Address;

public interface IAddressService {

	public List<Address> getAllAddress();
}
