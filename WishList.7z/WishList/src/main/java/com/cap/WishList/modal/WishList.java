package com.cap.WishList.modal;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name = "wish_list")
public class WishList {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "wish_id")
	private int wishId;
	@ManyToOne(fetch=FetchType.EAGER)	
	@JoinColumn(name="customer_id")
	private Customer customer;
	@OneToOne(fetch=FetchType.EAGER)	
	@JoinColumn(name="product_id")
	private Inventory inventory;
	public int getWishId() {
		return wishId;
	}
	public void setWishId(int wishId) {
		this.wishId = wishId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Inventory getInventory() {
		return inventory;
	}
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	public WishList(int wishId, Customer customer, Inventory inventory) {
		super();
		this.wishId = wishId;
		this.customer = customer;
		this.inventory = inventory;
	}
	public WishList() {
		super();
	}
	@Override
	public String toString() {
		return "WishList [wishId=" + wishId + ", customer=" + customer + ", inventory=" + inventory + "]";
	}
	
	

}
