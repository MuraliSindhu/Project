package com.cap.WishList.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cap.WishList.dao.WishListDao;
import com.cap.WishList.modal.WishList;


@Service("wishListService")
public class WishListServiceImpl implements WishListService{
	
	
	@Autowired
	private WishListDao wishListDao;

	@Override
	public List<WishList> getAll() {
		return wishListDao.findAll();
	}

	@Override
	public void save(WishList wishList) {
		wishListDao.save(wishList);
	}

	@Override
	public List<WishList> deleteWishList(Integer wishId) {
		wishListDao.deleteById(wishId);
		return wishListDao.findAll();
	}
	
	
}
