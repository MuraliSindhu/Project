package com.cap.WishList.service;

import java.util.List;

import com.cap.WishList.modal.WishList;

public interface WishListService {

	public List<WishList> getAll();
	public void save(WishList wishList);
	public List<WishList> deleteWishList(Integer wishId);

}
