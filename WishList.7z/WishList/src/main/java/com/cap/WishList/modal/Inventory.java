package com.cap.WishList.modal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Inventory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	
	@OneToOne(targetEntity=WishList.class, mappedBy="inventory")
	private WishList wishList;
	
	

	public Inventory() {
		super();
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public WishList getWishList() {
		return wishList;
	}

	public void setWishList(WishList wishList) {
		this.wishList = wishList;
	}

	public Inventory(int productId, WishList wishList) {
		super();
		this.productId = productId;
		this.wishList = wishList;
	}

	@Override
	public String toString() {
		return "Inventory [productId=" + productId + ", wishList=" + wishList + "]";
	}
	
}
