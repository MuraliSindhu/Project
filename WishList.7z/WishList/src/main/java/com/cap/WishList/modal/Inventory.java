package com.cap.WishList.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "inventory")
public class Inventory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "product_id")
	private int productId;
	
	/*@OneToOne(targetEntity=WishList.class, mappedBy="inventory")
	private WishList wishList;*/
	
	private String product_name;

	public Inventory() {
		super();
	}
	
	public Inventory(int productId, /*WishList wishList, */String product_name) {
		super();
		this.productId = productId;
		/*this.wishList = wishList;*/
		this.product_name = product_name;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	/*public WishList getWishList() {
		return wishList;
	}

	public void setWishList(WishList wishList) {
		this.wishList = wishList;
	}*/

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

}
