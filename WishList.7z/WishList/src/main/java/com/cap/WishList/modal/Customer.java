package com.cap.WishList.modal;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	
	@OneToMany(targetEntity = WishList.class, mappedBy = "customer")
	private List<WishList> wishList;
	

	public Customer() {
		super();
	}

	public Customer(int customerId, List<WishList> wishList) {
		super();
		this.customerId = customerId;
		this.wishList = wishList;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public List<WishList> getWishList() {
		return wishList;
	}

	public void setWishList(List<WishList> wishList) {
		this.wishList = wishList;
	}
	
	

}
