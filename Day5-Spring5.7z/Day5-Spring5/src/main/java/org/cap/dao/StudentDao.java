package org.cap.dao;

import java.util.List;

import org.cap.model.Student;

public interface StudentDao {
	
	public List<Student> getStudent();
	public Student findStudent(Integer studentId);
	public void update(Student student);

}
