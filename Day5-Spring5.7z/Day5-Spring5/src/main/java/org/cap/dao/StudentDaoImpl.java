package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;
@Repository("studentDao")
@Transactional
public class StudentDaoImpl implements StudentDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public List<Student> getStudent() {
		List<Student> students = entityManager.createQuery("from Student").getResultList();
		return students;
	}


	@Override
	public Student findStudent(Integer studentId) {
		Student student= entityManager.find(Student.class, studentId);
		return student;
	}


	@Override
	public void update(Student student) {
		if(student.getStudentId()!=0)
			entityManager.merge(student);
		else
			entityManager.persist(student);
	}
}
