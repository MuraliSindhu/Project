package org.cap.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.dao.StudentDao;
import org.cap.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("studentService")
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentDao studentDao;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Student> getStudent() {
		return studentDao.getStudent();
	}

	@Override
	public Student findStudent(Integer studentId) {
		return studentDao.findStudent(studentId);
	}

	@Override
	public void update(Student student) {
		studentDao.update(student);
	}

}
