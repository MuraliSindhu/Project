package org.cap.service;

import java.util.List;

import org.cap.model.Student;

public interface StudentService {
	
	public List<Student> getStudent();
	public Student findStudent(Integer studentId);
	public void update(Student student);

}
